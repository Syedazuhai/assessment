def userprocessfiles():
    sum_up = num_1 + num_2
    difference = num_1 - num_2
    product = num_1 * num_2
    quotient = num_1 / num_2