def useroutfiles(sum_up, difference, product, quotient):
    print("sum:" , sum_up)
    print("Difference:" + str(difference))
    print("product:" + str(product))
    print("Quotient:" + str(quotient))