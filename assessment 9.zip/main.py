from inputmodules import userinputfiles
from outputmodules import useroutfiles
from promodules import userprocessfiles

num_1, num_2 = userinputfiles()
sum_up = num_1 + num_2
difference = num_1 - num_2
product = num_1 * num_2
quotient = num_1 / num_2
useroutfiles(sum_up, difference, product, quotient)